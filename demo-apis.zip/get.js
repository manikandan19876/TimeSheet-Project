axios.get('http://localhost:4200/users')
  .then(function (response) {
    console.log(response);
  })