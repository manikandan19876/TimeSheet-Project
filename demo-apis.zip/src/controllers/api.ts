import { Request, Response } from "express";

import connection from "../services/db";

export function listAllProjects(req: Request, res: Response) {
  connection.query(
    "SELECT p.id, p.name projectname FROM custom_fields cf, custom_values cv, custom_options co, projects p where cf.type = 'ProjectCustomField' and cf.name = 'Project Phase'and cf.id = co.custom_field_id and cf.id = cv.custom_field_id and co.value = 'Inprogress'and cv.customized_id = p.id and cv.value::Int = co.id",
    function (err, results) {
      if (err) throw err;
      res.send(results);
    }
  );
  console.log("Listed All Projects..!!");
}

export function getUsers(req: Request, res: Response) {
  connection.query(
    "SELECT  u.firstname, r.rate, r.valid_from,r.type, p.name from rates r full outer join projects p on r.project_id  = p.id, users u where r.user_id = u.id and u.status = 1 order by 1",
    function (err, results) {
      if (err) throw err;
      res.send(results);
    });
  console.log("Listed All Users..!!");
}

export function getTimeSheetByUserForAllProjects(req: Request, res: Response) {
  var fromdate = req.query.from_dt;
  var todate = req.query.to_dt;

  connection.query(
    //`SELECT sum(hours), u.firstname , e.name as activityname from time_entries te, enumerations e , users u where te.user_id = u.id and te.activity_id = e.id and e.type = 'TimeEntryActivity'and te.spent_on between '${fromdate}' and '${todate}' group by u.firstname , e.name order by u.firstname`,
    `SELECT sum(hours), concat(u.firstname, ' ', u.lastname) fullname, u.id as userid, e.name as activityname, e.id as activityid, p.id project_id from time_entries te, enumerations e , users u, projects p where te.user_id = u.id and te.activity_id = e.id and e.type = 'TimeEntryActivity' and te.spent_on between '${fromdate}' and '${todate}'and te.project_id = p.id group by fullname, p.id, activityname, userid, activityid order by fullname, activityname`,
    function (err, results) {
      if (err) throw err;
      res.send(results);
    }
  );
  console.log("Listed timesheet grouped by users, for all projects..!!");
}

export function getTimeSheetByProjectsForAllProjects(req: Request, res: Response) {
  var fromdate = req.query.from_dt;
  var todate = req.query.to_dt;
  connection.query(
    `SELECT sum(hours), e.name as activityname,e.id as activityid,p."name" project from time_entries te, enumerations e , users u,projects p where te.user_id = u.id and te.activity_id = e.id and e.type = 'TimeEntryActivity' and te.spent_on between '${fromdate}' and '${todate}' and te.project_id = p.id group by activityname, activityid, p.id order by activityname`,
    function (err, results) {
      if (err) throw err;
      res.send(results);
    });
  console.log("Listed timesheet grouped by projects, for all projects..!!");
}

export function getTimeSheetByUserForOneProjects(req: Request, res: Response) {
  var projectid = req.query.project_id;
  var fromdate = req.query.from_dt;
  var todate = req.query.to_dt;
  connection.query(
    `SELECT sum(hours), concat(u.firstname, ' ', u.lastname) fullname, u.id as userid, e.name as activityname, e.id as activityid from time_entries te, enumerations e , users u, projects p where te.user_id = u.id and te.activity_id = e.id and e.type = 'TimeEntryActivity' and te.spent_on between '${fromdate}' and '${todate}' and te.project_id = p.id and te.project_id = '${projectid}' group by fullname , activityname, userid, activityid order by fullname, activityname`,
    function (err, results) {
      if (err) throw err;
      res.send(results);
    });
  console.log("Listed timesheet grouped by users, for one projects..!!");
}

export function getTimeSheetDrillDown(req: Request, res: Response) {
  var activityid = req.query.activity_id;
  var projectid = req.query.project_id;
  var userid = req.query.user_id;
  var fromdate = req.query.from_dt;
  var todate = req.query.to_dt;

  let query:string = `select te.spent_on, u.firstname , e.name as activityname, p.id as projectid, p.name as projectname, te.hours, te.comments 
  from time_entries te, enumerations e , users u, projects p
  where te.user_id = u.id 
  and te.activity_id = e.id 
  and e.type = 'TimeEntryActivity'
  and te.spent_on between '${fromdate}' and '${todate}'
  and te.project_id = p.id 
  -- and te.project_id = {project_id}
  and te.activity_id = ${activityid}
  and te.user_id = ${userid}
  order by te.spent_on`;

  if(projectid){
    query = query.replace('--','').replace('{project_id}',projectid as string)
  }
  connection.query(query, function (err, results) {
    if (err) throw err;
    res.send(results);
  });
  console.log("Listed timesheet drill down..!!");
}

export function getTimeSheetTimeSeries(req: Request, res: Response) {
  var fromdate = req.query.from_dt;
  var todate = req.query.to_dt;

  connection.query(
    `SELECT sum(hours) empworkhrs, wrkyear, wrkmonth, concat(u.firstname, ' ', u.lastname) fullname, e.name as activityname 
   from time_entries te, users u, enumerations e,
        (     
          select extract(year from workmonth) wrkyear, extract(month from workmonth) wrkmonth, 
            DATE_PART('days', DATE_TRUNC('month', workmonth) + '1 MONTH'::INTERVAL - '1 DAY'::INTERVAL) caldays
          from (
          select
              generate_series(
                  date_trunc('month', case when extract(day from '${fromdate}'::date)>=25 then '${fromdate}'::date + interval '1 month' else '${fromdate}'::date end), 
                  '${todate}'::date, '1 month'
              )::date as workmonth
          ) dates1
        ) dr
   where te.user_id = u.id 
   and te.activity_id = e.id 
   and e.type = 'TimeEntryActivity'
   and te.tyear = dr.wrkyear
   and te.tmonth = dr.wrkmonth
   group by wrkyear, wrkmonth, fullname, activityname
   order by 4,2,3`,
    function (err, results) {
      if (err) throw err;
      res.send(results);
    });
  console.log("Listed timesheet timeseries..!!");
}


