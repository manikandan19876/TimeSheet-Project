import pg from "pg";
import * as dotenv from "dotenv";
dotenv.config();


var config = {
    host: process.env.db_host,
    port: process.env.db_port,
    user: process.env.db_user,
    password: process.env.db_pwd,
    database: process.env.db_name,
    schema: process.env.db_schema,
  };
  
  var connection = new pg.Pool(config);
  
  export default connection;
  
  connection.connect((err) => {
    if (err) {
      console.log('Error connecting to Db');
    }
    else{
      console.log('DB connected successfully...');
    }
  });