import { Express } from "express";
import * as fetchcontroller from "./src/controllers/api";

export default function bindRoutes(app:Express){
    app.get("/projects", fetchcontroller.listAllProjects);
    app.get("/users", fetchcontroller.getUsers);
    app.get("/usertimesheet", fetchcontroller.getTimeSheetByUserForAllProjects);
    app.get("/projectstimesheet", fetchcontroller.getTimeSheetByProjectsForAllProjects);
    app.get("/usertimesheetforoneprojects", fetchcontroller.getTimeSheetByUserForOneProjects);
    app.get("/timesheetdrilldown", fetchcontroller.getTimeSheetDrillDown);
    app.get("/timeseries?from_dt=10-09-2021 & to_dt=18-10-2021", fetchcontroller.getTimeSheetTimeSeries);


}